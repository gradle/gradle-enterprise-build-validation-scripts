#!/usr/bin/env bash
#
# Runs Experiment 02 - Validate Build Caching - Local - In Place
#
# Invoke this script with --help to get a description of the command line arguments
#
readonly SCRIPT_NAME=$(basename "$0")
readonly SCRIPT_DIR="$(cd "$(dirname "$(readlink -e "${BASH_SOURCE[0]}")")" && pwd)"
readonly LIB_DIR="${SCRIPT_DIR}/lib"

# Experiment-specific constants
readonly EXP_NAME="Validate Build Caching - Continuous Integration to Local"
readonly EXP_DESCRIPTION="Validating that a Gradle build is optimized for remote build caching"
readonly EXP_NO="05"
readonly EXP_SCAN_TAG=exp5-gradle
readonly EXP_DIR="${SCRIPT_DIR}/data/${SCRIPT_NAME%.*}"
readonly SCAN_FILE="${EXP_DIR}/scans.csv"
readonly BUILD_TOOL="Gradle"

build_cache_dir="${EXP_DIR}/build-cache"

# These will be set by the config functions (see lib/config.sh)
git_repo=''
project_name=''
git_branch=''
project_dir=''
tasks=''
extra_args=''
enable_ge=''
ge_server=''
interactive_mode=''

ci_build_scan_url=''
ci_build_scan_id=''
commit_id=''

# Include and parse the command line arguments
# shellcheck source=build-validation-automation/scripts/src/lib/gradle/05-cli-parser.sh
source "${LIB_DIR}/gradle/${EXP_NO}-cli-parser.sh" || { echo "Couldn't find '${LIB_DIR}/gradle/${EXP_NO}-cli-parser.sh' parsing library."; exit 1; }
# shellcheck source=build-validation-automation/scripts/src/lib/libs.sh
source "${LIB_DIR}/libs.sh" || { echo "Couldn't find '${LIB_DIR}/libs.sh'"; exit 1; }

readonly RUN_ID=$(generate_run_id)

main() {
  if [ "${interactive_mode}" == "on" ]; then
    wizard_execute
  else
    execute
  fi
}

execute() {
  validate_required_config
  validate_required_args

  make_experiment_dir
  lookup_ci_scan_data

  git_clone_project ""
  git_checkout_commit "${commit_id}"
  print_bl
  execute_build

  print_warnings
  print_bl
  print_summary
}

wizard_execute() {
  print_introduction

  make_experiment_dir

  explain_collect_build_scan
  collect_build_scan
  lookup_ci_scan_data

  collect_git_details

  explain_collect_gradle_details
  collect_gradle_details

  explain_clone_project
  git_clone_project ""

  explain_build
  execute_build

  print_warnings
  explain_warnings

  explain_summary
  explain_how_to_repeat_the_experiment
}

validate_required_args() {
  if [ -z "${_arg_build_scan}" ]; then
    _PRINT_HELP=yes die "ERROR: Missing required argument: --build-scan" 1
  fi
  ci_build_scan_url="${_arg_build_scan}"
}

lookup_ci_scan_data() {
  # From https://stackoverflow.com/a/63993578/106189
  # See also https://stackoverflow.com/a/45977232/106189
  readonly URI_REGEX='^(([^:/?#]+):)?(//((([^:/?#]+)@)?([^:/?#]+)(:([0-9]+))?))?((/|$)([^?#]*))(\?([^#]*))?(#(.*))?$'
  #                    ↑↑            ↑  ↑↑↑            ↑         ↑ ↑            ↑↑    ↑        ↑  ↑        ↑ ↑
  #                    ||            |  |||            |         | |            ||    |        |  |        | |
  #                    |2 scheme     |  ||6 userinfo   7 host    | 9 port       ||    12 rpath |  14 query | 16 fragment
  #                    1 scheme:     |  |5 userinfo@             8 :...         ||             13 ?...     15 #...
  #                                  |  4 authority                             |11 / or end-of-string
  #                                  3  //...                                   10 path

  local protocol ge_host build_scan_id access_token encoded_token build_scan_data_url scan_data
  if [[ "${ci_build_scan_url}" =~ $URI_REGEX ]]; then
    protocol="${BASH_REMATCH[2]}"
    ge_host="${BASH_REMATCH[7]}"
    build_scan_id="$(basename "${BASH_REMATCH[10]}")"

    access_token="$(grep "^${ge_host}=" "$HOME/.gradle/enterprise/keys.properties" | cut -d '=' -f 2)"
    encoded_token="$(echo -n "${access_token}" | base64)"

    build_scan_data_url="${protocol}://${ge_host}/scan-data/${build_scan_id}"
    scan_data="$(curl -f -k -s -H "Authorization: Bearer ${encoded_token}" -H "Accept: application/json" "${build_scan_data_url}")" \
      || die "ERROR: Unable to fetch the build scan data using ${build_scan_data_url}."

    # Set variables for use later on
    commit_id="$(echo -n "${scan_data}" | jq -r '.data.customValues.items[] | select(.name == "Git commit id") | .value')"
    ci_build_scan_id=${build_scan_id}

    # Save the parsed data to the scans.csv
    echo "${protocol}://${ge_host},${build_scan_id},${ci_build_scan_url}" > "${SCAN_FILE}"
  else
    die "${build_scan_url} is not a parsable URL." 4
  fi
}

execute_build() {
  # The gradle --init-script flag only accepts a relative directory path. ¯\_(ツ)_/¯
  local lib_dir_rel
  lib_dir_rel="$(relative_lib_path)"

  info
  info "Running build:"
  info "./gradlew -Dscan.tag.${EXP_SCAN_TAG} -Dscan.tag.${RUN_ID} clean ${tasks}$(print_extra_args)"

  invoke_gradle \
     --init-script "${lib_dir_rel}/gradle/verify-and-configure-remote-build-cache-only.gradle" \
     clean "${tasks}"
}

print_summary() {
 read_scan_info
 print_experiment_info
 print_build_scans
 print_bl
 print_quick_links
 print_bl
}

print_build_scans() {
 local fmt="%-25s%-10s"
 infof "$fmt" "Build scan first build:" "${scan_url[0]}"
 infof "$fmt" "Build scan second build:" "${scan_url[1]}"
}

print_quick_links() {
 local fmt="%-25s%-10s"
 info "Investigation Quick Links"
 info "-------------------------"
 infof "$fmt" "Task execution overview:" "${base_url[0]}/s/${scan_id[1]}/performance/execution"
 infof "$fmt" "Cache performance:" "${base_url[0]}/s/${scan_id[1]}/performance/build-cache"
 infof "$fmt" "Executed tasks timeline:" "${base_url[0]}/s/${scan_id[1]}/timeline?outcome=SUCCESS,FAILED&sort=longest"
 infof "$fmt" "Task inputs comparison:" "${base_url[0]}/c/${scan_id[0]}/${scan_id[1]}/task-inputs"
 infof "$fmt" "Executed tasks:" "${base_url[0]}/s/${scan_id[1]}/timeline?outcome=SUCCESS,FAILED&sort=longest"
 infof "$fmt" "Executed cacheable tasks:" "${base_url[0]}/s/${scan_id[1]}/timeline?cacheableFilter=cacheable&outcomeFilter=SUCCESS,FAILED&sorted=longest"
 infof "$fmt" "Non-cacheable tasks:" "${base_url[0]}/s/${scan_id[1]}/timeline?cacheableFilter=any_non-cacheable&outcomeFilter=SUCCESS,FAILED&sorted=longest"
}

print_introduction() {
  local text
  IFS='' read -r -d '' text <<EOF
$(print_introduction_title)

In this experiment, you will validate how well a given project leverages
Gradle's remote caching functionality to avoid doing unnecessary work that
has already been done on a Continuous Integration server.

A build is considered fully leveraging the remote cache if all tasks avoid
performing any work because all of the task outputs were found in the remote
cache when:

  * The local cache is empty or disabled
  * The tasks' inputs have not changed since their outputs were saved in the
    remote cache

The goal of this experiment is to first identify those tasks that do not
reuse outputs from the remote cache (when run locally), to then investigate
why, and to finally make an informed decision of which tasks are worth
improving to make your build faster.

This experiment consists of the following steps:

  1. On a Continuous Integration server, run the Gradle build with a typical
     task invocation

  2. Locally, check out the same commit that was built on the Continuous
     Integration server

  3. Locally, run the Gradle build with the same typical task invocation
     including the 'clean' task

  4. Determine which tasks are still executed in the second run and why

  5. Assess which of the executed tasks are worth improving

The script you have invoked automates the execution of step 2 and step 3,
without modifying the project. Step 1 must be completed prior to running
this script. Build scans support your investigation in step 4 and step 5.

After improving the build to make it more incremental, you can run the
experiment again. This creates a cycle of run → measure → improve → run → …

${USER_ACTION_COLOR}Press <Enter> to get started with the experiment.${RESTORE}
EOF

  print_wizard_text "${text}"
  wait_for_enter
}

collect_build_scan() {
  prompt_for_setting "What is the build scan for the CI server build?" "${_arg_build_scan}" "" ci_build_scan_url
}

explain_collect_build_scan() {
  local text
  IFS='' read -r -d '' text <<EOF
$(print_separator)
${HEADER_COLOR}Configure experiment${RESTORE}
We will use data from the CI build scan (the build scan generated in step 1) to lookup:

  * the commit ID the CI build ran against
  * the tasks and arguments the CI build invoked Gradle with

EOF
  print_wizard_text "${text}"
}

explain_build() {
  local text
  IFS='' read -r -d '' text <<EOF
$(print_separator)
${HEADER_COLOR}Run local build${RESTORE}

We are now ready to run the local build.

We will execute 'clean ${tasks}'.

We are invoking clean even though we just created a fresh clone because
sometimes the clean task changes the order other tasks run in, which can
impact how the build cache is utilized.

We will also add a few build scan tags.

${USER_ACTION_COLOR}Press <Enter> to run the local build.${RESTORE}
EOF
  print_wizard_text "${text}"
  wait_for_enter
}

explain_summary() {
  read_scan_info
  local text
  IFS='' read -r -d '' text <<EOF
$(print_separator)
${HEADER_COLOR}Measure build results{RESTORE}

Now that the local build has completed, there is a lot of valuable data in
Gradle Enterprise to look at. The data can help you find inefficiencies in
your build.

After running the experiment, this script will generate a summary table of
useful data and links to help you analyze the experiment results:

$(print_experiment_info)

"Experiment id" and "Experiment run id" are added as tags on the build
scans.

You can use the "Experiment id" to find all of the build scans for all runs
of this experiment.

Every time you run this script, we'll generate a unique "Experiment run id".
You can use the run id to search for the build scans from a specific run of the
experiment.

$(print_build_scans)

Above are links to the build scans from this experiment. A build scan provides
a wealth of information and statistics about the build execution.

$(print_quick_links)

Use the above links help you get started in your analysis.

The first link is to a comparison of the two build scans. Comparisons show you
what was different between two different build executions.

The "Task execution summary" shows overall statistics for the execution of
the second build. You can use this link to get a quick overview of where
there may be overall opportunities to optimize.

The "Cache performance" link takes you to the build cache performance page
of the 2nd build scan. This page contains various metrics related to the
build cache (such as cache hits and misses).

The "Executed tasks" link takes you to the timeline view of the second build
scan and automatically shows only the tasks that were executed, sorted by
execution time (with the longest-running tasks listed first). You can use
this to quickly identify tasks that were executed again unnecessarily. You
will want to optimize any such tasks that take a significant amount of time
to complete.

The "Executed cacheable tasks" link shows you which tasks ran again on the
second build, but shouldn't have because they are actually cacheable. If any
cacheable tasks ran, then one of their inputs changed (even though we didn't
make any changes), or they may not be declaring their inputs correctly.

The last link, "Non-cacheable tasks", shows you which tasks ran that are not
cacheable. It is not always possible (or doesn't make sense) to cache the
output from every task. For example, there is no way to cache the "output"
of the clean task because the clean task deletes output rather than creating
it.
EOF
  print_wizard_text "${text}"
}

process_arguments "$@"
main

